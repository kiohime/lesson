--DC.ExecuteCommand("cm_FocusSwap", "side=right")
--DC.ExecuteCommand("cm_NewTab")
--DC.ExecuteCommand("cm_ChangeDir, rightpath= ")
DC.ExecuteCommand("cm_PasteFromClipboard")