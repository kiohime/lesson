Language files in this directory are part of Lazarus.
This directory synchronized with current Lazarus version.
If you want to translate it then send translation to Lazarus project.

https://www.lazarus-ide.org
https://svn.freepascal.org/cgi-bin/viewvc.cgi/trunk/lcl/languages/?root=lazarus
